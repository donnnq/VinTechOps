rm -rf /tmp/*
