#!/data/data/com.termux/files/usr/bin/bash
tail -n 10 ~/VinScripts/execution_history.log
