#!/data/data/com.termux/files/usr/bin/bash
grep -i "$@" ~/VinScripts/execution_history.log
