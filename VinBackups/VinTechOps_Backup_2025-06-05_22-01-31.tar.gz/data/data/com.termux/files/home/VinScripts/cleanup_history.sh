#!/data/data/com.termux/files/usr/bin/bash
find ~/VinScripts/execution_history.log -mtime +30 -exec rm {} \;
