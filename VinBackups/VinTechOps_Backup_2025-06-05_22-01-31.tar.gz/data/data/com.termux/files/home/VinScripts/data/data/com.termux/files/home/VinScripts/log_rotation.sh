#!/bin/bash
logrotate --state ~/VinLogs/logrotate.status --force ~/VinLogs/logrotate.conf
