#!/bin/bash
find ~/VinLogs -type f -size +5M -exec rm -f {} \;
