#!/bin/bash
exec script ~/VinLogs/full_debug.log
